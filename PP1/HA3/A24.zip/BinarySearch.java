package binarysearch;
import utils.IO1;

public class BinarySearch {

    static private int Merker;
    static private int Position;
    public static void main(String[] args) {
        int i,x;
        String neustart;
        String Such;
        do {
            System.out.println("Bitte eine ganze Zahl eingeben. Wie viele Wörter werden eingelesen?");
            i = IO1.einint();
        }while(i>=6);

        String[] Words = new String[i];
        for(x=1; x<=i; x++){
            System.out.println("Bitte geben Sie das " + x + ". Wort an.");
            Words[x-1] = IO1.einstring();
        }

        do{
            System.out.println("Bitte geben Sie das zu suchende Wort an");
            Such = IO1.einstring();
            Suchfunktion(Words,Such);
            if (BinarySearch.Merker == 1){
             System.out.println("Gefunden an Position:" + BinarySearch.Position);
            }
            else{System.out.println("Nicht gefunden");}
            System.out.println("Eine neue Suche starten?(j/n)");
            neustart = IO1.einstring();

        }while("j".equals(neustart));         
    }
    
public static void Suchfunktion( String[] Sucharray, String Suche){
    int i,li,mi,re;
    i = Sucharray.length;
    li = 0;
    re = i-1;
    BinarySearch.Merker = 0;
    do {
        mi = (li+re)/2;
        int result = Sucharray[mi].compareTo(Suche);
        if(result == 0){
            BinarySearch.Position = mi;
            BinarySearch.Merker = 1;
            li = re;
            mi = re;
            
        }
        if(result > 0){             
        re = mi - 1;
        }
        if(result < 0){  
        li = mi + 1;
        }
     if (li > re){li=0;re=0;mi=0;}
    }while(mi!=li || mi!=re);
   
}       



}
    


    
