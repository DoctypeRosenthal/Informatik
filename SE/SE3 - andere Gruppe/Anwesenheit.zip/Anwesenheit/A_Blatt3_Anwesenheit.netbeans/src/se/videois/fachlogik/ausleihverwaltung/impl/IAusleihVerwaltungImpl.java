/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.videois.fachlogik.ausleihverwaltung.impl;
import se.videois.datenhaltung.db.entities.Ausleihvorgang;
import se.videois.datenhaltung.db.entities.Artikel;
import se.videois.datenhaltung.db.entities.Kunde;
import se.videois.datenhaltung.db.impl.ICRUDArtikelImpl;
import se.videois.datenhaltung.db.impl.ICRUDAusleihvorgangImpl;
import se.videois.datenhaltung.db.impl.ICRUDKundeImpl;
import se.videois.fachlogik.grenzklasen.AusleihQuittung;
import se.videos.fachlogik.ausleihverwaltung.services.IAusleihVerwaltung;

/**
 *Steuereungsklasse IAusleihVerwaltungImpl
 * implementiert Funktion(-en) zum Artikel ausleihen 
 * @author Gruppe 7
 * @version 1.0
 */
public class IAusleihVerwaltungImpl implements IAusleihVerwaltung{   
    /**
    *Methode zur Realisierung des Anwendungsfalls
    * /LF20/ Artikel Ausleihen
    * 
    * @param knr:int = Kundennummer des Kunden
    * @param anr:int = Artikelnummer des auszuleihenden Artikels
    * @return AusleihQuittung
    */
    public AusleihQuittung artikelAusleihen(int knr, int anr){
        AusleihQuittung quittung=null;
        ICRUDKundeImpl crudkunde = new ICRUDKundeImpl();
        Kunde kunde = crudkunde.getKundeByID(knr);
        ICRUDArtikelImpl crudartikel= new ICRUDArtikelImpl();
        Artikel artikel = crudartikel.getArtikelByID(anr);
        int mindestalter=artikel.getMindestalter();
        int gebjahr=kunde.getGebjahr();
        int alter = 2018-gebjahr;
        if(alter>=mindestalter){
            Ausleihvorgang av= new Ausleihvorgang(kunde, artikel, 28);
            av.setBeginn("15.01.18");
            av.setEnde("20.01.18");
            ICRUDAusleihvorgangImpl crudAusleihvorg= new ICRUDAusleihvorgangImpl();
            if (crudAusleihvorg.insertAusleihvorgang(av)){
                System.out.println("Ausleihvorgang erfasst");
            }
            artikel.setVerfuegbar(false);
            quittung = new AusleihQuittung(knr, anr, "15.01.18",28);
        }
        
    
        return quittung;
    }

}
