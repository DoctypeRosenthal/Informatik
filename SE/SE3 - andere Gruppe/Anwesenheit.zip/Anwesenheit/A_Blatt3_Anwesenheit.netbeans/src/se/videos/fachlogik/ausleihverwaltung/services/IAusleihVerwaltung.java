/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package se.videos.fachlogik.ausleihverwaltung.services;

import se.videois.fachlogik.grenzklasen.AusleihQuittung;

/**
 *
 * @author user
 */
public interface IAusleihVerwaltung {
     public AusleihQuittung artikelAusleihen(int knr, int anr);
}
