package se.videos.fachlogik.ausleihverwaltung.tests;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import se.videois.datenhaltung.db.entities.Artikel;
import se.videois.datenhaltung.db.entities.Ausleihvorgang;
import se.videois.datenhaltung.db.entities.Kunde;
import se.videois.datenhaltung.db.impl.ICRUDArtikelImpl;
import se.videois.datenhaltung.db.impl.ICRUDAusleihvorgangImpl;
import se.videois.datenhaltung.db.impl.ICRUDKundeImpl;
import se.videois.datenhaltung.db.services.ICRUDArtikel;
import se.videois.datenhaltung.db.services.ICRUDAusleihvorgang;
import se.videois.datenhaltung.db.services.ICRUDKunde;
import se.videois.fachlogik.ausleihverwaltung.impl.IAusleihVerwaltungImpl;
import se.videois.fachlogik.grenzklasen.AusleihQuittung;
import se.videos.fachlogik.ausleihverwaltung.services.IAusleihVerwaltung;

/**
 *
 * @author user
 */
public class VideoTesten {
    private static Kunde kunde;
    private static Artikel artikel;
    private static Ausleihvorgang av;
    private static AusleihQuittung quittung;
    
    
    public VideoTesten() {
    
    
    }
    
    @BeforeClass
    public static void erzeugeTestDaten() {
        kunde=new Kunde("David","Koeln",1995,"123",45);
        artikel=new Artikel(true,255,"Koeln",18,30);
            
        ICRUDKunde crudkunde = new ICRUDKundeImpl();
        crudkunde.insertKunde(kunde);
        ICRUDArtikel crudartikel = new ICRUDArtikelImpl();
        crudartikel.insertArtikel(artikel);
        IAusleihVerwaltung ausleih = new IAusleihVerwaltungImpl();  
        quittung=ausleih.artikelAusleihen(45,255);
    
        ICRUDAusleihvorgang crudaus = new ICRUDAusleihvorgangImpl();
        av=crudaus.getAusleihvorgangByID(quittung.getAusleihnr());
    
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    // TODO add test methods here.
    // The methods must be annotated with annotation @Test. For example:
    //
    //1. Ausleihquittung wurde erstellt und besitzt korrekte Daten 
    @Test
     public void test_ausleihvorgang1() {
         assertEquals(artikel.getArtikelnr(),quittung.getArtikelnr());
         assertEquals(kunde.getKundenr(),quittung.getKundennr());
         assertEquals(28,quittung.getAusleihnr());
         assertEquals("15.01.18",quittung.getAusleihdatum());
     }
     
      //2. Artikel als verliehen markiert
     @Test
     public void test_ausleihvorgang2() {
         assertFalse(artikel.isVerfuegbar());
     }
     
    //3. Ausleihvorgang im System mit korrektem Datum 
     @Test
     public void test_ausleihvorgang3() {
         assertEquals("15.01.18", av.getBeginn());
         assertEquals(28,av.getAusleihnr());
     }
   //4. Ausleihquittung ist mit Kunden verbunden 
     @Test
     public void test_ausleihvorgang4() {
         assertSame(kunde, av.getKunde());
     }
    //5. Ausvorgang mit Artikel verbunden 
     @Test
     public void test_ausleihvorgang5() {
         assertSame(artikel, av.getArtikel());
     }
     //6. Kunde mit Ausleihvorgang verbunden 
      @Test
    public void test_ausleihvorgang6() {
        assertSame(av.getKunde(), kunde);
     }
    //7. Artikel ist mit Ausleihvorgan verbunden 
    @Test
    public void test_ausleihvorgang7() {
        assertSame(av.getArtikel(), artikel);
    }









}
